-- phpMyAdmin SQL Dump
-- version 4.2.12deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 04, 2015 at 04:32 PM
-- Server version: 5.6.25-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `microfinance`
--
CREATE DATABASE IF NOT EXISTS `microfinance` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `microfinance`;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`id` int(11) NOT NULL,
  `emp_id` varchar(124) NOT NULL,
  `balance` float NOT NULL,
  `acct_type` int(14) NOT NULL,
  `d_opened` date NOT NULL,
  `duration` date NOT NULL,
  `acct_no` varchar(124) NOT NULL,
  `save_amt` float NOT NULL,
  `acct_name` varchar(124) NOT NULL,
  `amt_todate` float DEFAULT NULL,
  `department` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `emp_id`, `balance`, `acct_type`, `d_opened`, `duration`, `acct_no`, `save_amt`, `acct_name`, `amt_todate`, `department`) VALUES
(1, '5', -4.4, 1, '2015-09-02', '2115-09-02', 'TSA6046007', 5000, 'smile mmumene', NULL, 1),
(4, '5', 45, 2, '2015-09-02', '1970-01-01', 'SSA0276544', 5000, 'smile mmumene', NULL, 0),
(5, '5', 0, 2, '2015-09-02', '2020-09-02', 'SSA4645268', 5000, 'smile mmumene', NULL, 0),
(6, '5', 0, 2, '2015-09-02', '2020-09-02', 'SSA3809260', 5000, 'smile mmumene', NULL, 0),
(7, '5', 0, 1, '2015-09-02', '2115-09-02', 'TSA3929672', 5000, 'smile mmumene', NULL, 0),
(8, '5', 0, 1, '2015-09-02', '2115-09-02', 'TSA8061204', 5000, 'smile mmumene', NULL, 0),
(9, '5', 0, 1, '2015-09-02', '2115-09-02', 'TSA8992366', 9000, 'jjjks jsjksjk', NULL, 0),
(10, '5', 0, 1, '2015-09-02', '2115-09-02', 'TSA7428188', 9000, 'jjjks jsjksjk', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `acct_type`
--

CREATE TABLE IF NOT EXISTS `acct_type` (
`id` int(11) NOT NULL,
  `name` varchar(124) NOT NULL,
  `fixed_duration` int(124) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acct_type`
--

INSERT INTO `acct_type` (`id`, `name`, `fixed_duration`) VALUES
(1, 'Thrift', 5),
(2, 'Special', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`id` int(11) NOT NULL,
  `middle_name` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `sex` text NOT NULL,
  `img_url` varchar(196) DEFAULT NULL,
  `faculty` text NOT NULL,
  `dept` int(11) NOT NULL,
  `address` text NOT NULL,
  `phone` int(196) NOT NULL,
  `state` text NOT NULL,
  `lga` text NOT NULL,
  `nok_name` text,
  `n_phone` int(11) DEFAULT NULL,
  `reg_date` date NOT NULL,
  `uname` varchar(124) NOT NULL,
  `pwd` text NOT NULL,
  `priviledge` int(124) NOT NULL,
  `email` varchar(124) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `surname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `employee_no` varchar(124) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `middle_name`, `dob`, `sex`, `img_url`, `faculty`, `dept`, `address`, `phone`, `state`, `lga`, `nok_name`, `n_phone`, `reg_date`, `uname`, `pwd`, `priviledge`, `email`, `title`, `surname`, `firstname`, `employee_no`) VALUES
(1, 'jkkjkjk', '2015-08-27', 'male', NULL, 'jkjk', 0, 'jkjkkj', 2147483647, '', '', 'jkjkj', 9090, '2015-08-26', 'admin', '12345', 0, 'jkjk@gmail.com', NULL, 'jkjk', 'jjsjkskds', ''),
(5, 'Smile', '1992-10-22', 'male', '5.jpg', 'Science', 1, '66 new airport road', 2147483647, 'Cross River', 'abi', 'smle', 2147483647, '2015-08-31', 'smilecs', '12345', 2, 'mumene@gmail.com', NULL, 'Mmumene', 'Smile', 'em5670po');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`id` int(11) NOT NULL,
  `dep_name` varchar(124) NOT NULL,
  `faculty` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `dep_name`, `faculty`) VALUES
(1, 'Science', 1);

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE IF NOT EXISTS `deposit` (
`id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  `acct_no` varchar(124) NOT NULL,
  `dep_id` int(30) NOT NULL,
  `teller_id` int(30) NOT NULL,
  `balance` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
`id` int(11) NOT NULL,
  `name` varchar(124) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`) VALUES
(1, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
`id` int(11) NOT NULL,
  `emp_no` varchar(124) NOT NULL,
  `date_incured` date NOT NULL,
  `amount` float NOT NULL,
  `paid` int(124) NOT NULL,
  `interest` int(124) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `total` float NOT NULL,
  `amort` float NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`id`, `emp_no`, `date_incured`, `amount`, `paid`, `interest`, `status`, `total`, `amort`) VALUES
(3, '5', '2015-09-04', 6000, 0, 10, 0, 8400, -143.046),
(4, '5', '2015-09-04', 6000, 0, 10, 0, 8400, -143.046),
(5, '5', '2015-09-04', 6000, 0, 10, 0, 8400, 143.046),
(6, '5', '2015-09-04', 6000, 0, 10, 0, 8400, 143.046),
(7, '5', '2015-09-04', 6000, 0, 10, 0, 9000, 116.223),
(8, '5', '2015-09-04', 6000, 0, 10, 0, 8400, 143.05),
(9, '5', '2015-09-04', 100000, 0, 10, 0, 140000, 2384.1),
(10, '5', '2015-09-04', 100000, 0, 10, 0, 140000, 2384.1);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
`id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `amount_pay` float NOT NULL,
  `balance` float NOT NULL,
  `l_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `emp_id`, `amount_pay`, `balance`, `l_id`, `date`) VALUES
(1, 5, 0, 0, 1, '2015-09-04');

-- --------------------------------------------------------

--
-- Table structure for table `percent`
--

CREATE TABLE IF NOT EXISTS `percent` (
`id` int(11) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `value` int(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `percent`
--

INSERT INTO `percent` (`id`, `p_name`, `value`) VALUES
(1, 'withdraw', 10),
(2, 'loan', 10),
(3, 'duration', 100);

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

CREATE TABLE IF NOT EXISTS `withdraw` (
`id` int(11) NOT NULL,
  `acct_no` varchar(124) NOT NULL,
  `amount` float NOT NULL,
  `total_deduction` float NOT NULL,
  `date` int(11) NOT NULL,
  `teller_id` int(11) NOT NULL,
  `balance` float NOT NULL,
  `emp_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdraw`
--

INSERT INTO `withdraw` (`id`, `acct_no`, `amount`, `total_deduction`, `date`, `teller_id`, `balance`, `emp_id`) VALUES
(1, 'TSA6046007', 4, 4.4, 15, 0, -4.4, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acct_type`
--
ALTER TABLE `acct_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `percent`
--
ALTER TABLE `percent`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw`
--
ALTER TABLE `withdraw`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `acct_type`
--
ALTER TABLE `acct_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `percent`
--
ALTER TABLE `percent`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `withdraw`
--
ALTER TABLE `withdraw`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
